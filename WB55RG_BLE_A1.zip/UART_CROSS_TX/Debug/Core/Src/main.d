Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal.h \
 ../Core/Inc/stm32wbxx_hal_conf.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_dma.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32WBxx/Include/stm32wbxx.h \
 ../Drivers/CMSIS/Device/ST/STM32WBxx/Include/stm32wb55xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32WBxx/Include/system_stm32wbxx.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_dma.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_dmamux.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_dma_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_cortex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_exti.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_flash.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_flash_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_gpio.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_gpio_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_hsem.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_ipcc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_pwr.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_pwr.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_exti.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_pwr_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rcc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rcc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_bus.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rcc_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_crs.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rtc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rtc_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_uart.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_uart_ex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_system.h \
 ../Core/Inc/app_conf.h \
 ../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/hw.h \
 ../Core/Inc/hw_conf.h ../Core/Inc/hw_if.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_exti.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_system.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rcc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_ipcc.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_bus.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_pwr.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_cortex.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_utils.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_hsem.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_gpio.h \
 ../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rtc.h \
 ../Middlewares/ST/STM32_WPAN/ble/core/ble_bufsize.h \
 ../Core/Inc/app_entry.h ../Core/Inc/app_common.h ../Core/Inc/logger.h \
 ../Core/Inc/logger_lpuart.h ../Core/Inc/main.h \
 ../STM32_WPAN/App/app_ble.h \
 ../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/tl/hci_tl.h \
 ../Middlewares/ST/STM32_WPAN/stm32_wpan_common.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/tl/tl.h \
 ../Core/Inc/app_common.h ../Core/Inc/hw_conf.h
../Core/Inc/main.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal.h:
../Core/Inc/stm32wbxx_hal_conf.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_dma.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32WBxx/Include/stm32wbxx.h:
../Drivers/CMSIS/Device/ST/STM32WBxx/Include/stm32wb55xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32WBxx/Include/system_stm32wbxx.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_dma.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_dmamux.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_dma_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_cortex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_exti.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_flash.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_flash_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_gpio.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_gpio_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_hsem.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_ipcc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_pwr.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_pwr.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_exti.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_pwr_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rcc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rcc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_bus.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rcc_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_crs.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rtc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_rtc_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_uart.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_hal_uart_ex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_system.h:
../Core/Inc/app_conf.h:
../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/hw.h:
../Core/Inc/hw_conf.h:
../Core/Inc/hw_if.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_exti.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_system.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rcc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_ipcc.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_bus.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_pwr.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_cortex.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_utils.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_hsem.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_gpio.h:
../Drivers/STM32WBxx_HAL_Driver/Inc/stm32wbxx_ll_rtc.h:
../Middlewares/ST/STM32_WPAN/ble/core/ble_bufsize.h:
../Core/Inc/app_entry.h:
../Core/Inc/app_common.h:
../Core/Inc/logger.h:
../Core/Inc/logger_lpuart.h:
../Core/Inc/main.h:
../STM32_WPAN/App/app_ble.h:
../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/tl/hci_tl.h:
../Middlewares/ST/STM32_WPAN/stm32_wpan_common.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Middlewares/ST/STM32_WPAN/interface/patterns/ble_thread/tl/tl.h:
../Core/Inc/app_common.h:
../Core/Inc/hw_conf.h:
